#include <time.h>

extern "C" int factoral(int n);
extern "C" int my_mod(int x, int y);
extern "C" char *get_time();

